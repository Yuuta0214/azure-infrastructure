# ==========================================
# 1. 基盤・環境定義
# ==========================================
# 01_network 側の定義および 02_compute.yml と整合
location     = "japanwest"
environment  = "dev"

# ==========================================
# 2. コンピューティング定義 (VMスペック)
# ==========================================
vm_size      = "Standard_D2s_v3"
lb_backend_pool_name = "BackendPool-web-dev"

# ==========================================
# 3. メタデータ定義 (運用管理用)
# ==========================================
# 01_network 側のタグ構成（Production-Dev / WEB-201）と完全に一致させる
tags = {
  BusinessUnit = "Production-Dev"
  CostCenter   = "WEB-201"
}